package com.example.admin.javaui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.Button;
import android.graphics.Color;
import android.widget.EditText;
import android.content.res.Resources;
import android.util.TypedValue;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //creating layout objects
        RelativeLayout Atul = new RelativeLayout(this);
        Atul.setBackgroundColor(Color.BLUE);

        Button b = new Button(this);
        b.setText("Click me");
        b.setBackgroundColor(Color.RED);

        RelativeLayout.LayoutParams posn = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT
        );
        posn.addRule(RelativeLayout.CENTER_HORIZONTAL);
        posn.addRule(RelativeLayout.CENTER_VERTICAL);

        EditText username = new EditText(this);

        b.setId(1);
        Atul.setId(2);

        RelativeLayout.LayoutParams usernameposn = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT
        );
        usernameposn.addRule(RelativeLayout.ABOVE,b.getId());
        usernameposn.addRule(RelativeLayout.CENTER_HORIZONTAL);
        usernameposn.setMargins(0,0,0,50);

        Resources r = getResources();
        int px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,200,r.getDisplayMetrics());
        username.setWidth(px);

        Atul.addView(b,posn);
        Atul.addView(username,usernameposn);
        setContentView(Atul);
    }
}
